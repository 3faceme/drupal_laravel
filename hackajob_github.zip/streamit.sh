#!/bin/sh



#vlc --sout-all --sout '#transcode{vcodec=none,acodec=mp3,ab=128}:standard{access=http,mux=raw,dst=192.168.1.37:8080}'

#vlc -vvv "playlist.m3u" --sout-keep '#transcode{vcodec=none,acodec=mp3,ab=128}:standard{access=http,mux=raw,dst=192.168.1.37:8080}' 
#vlc -vvv "RSF_playlist_col_only.m3u" --sout '#transcode{vcodec=none,acodec=mp3,ab=128}:standard{access=http,mux=raw,dst=192.168.1.37:8080}'

#duplicate{dst=std{access=http,mux=ts,dst=192.168.208.128:8080},dst=nodisplay}:sout-

cvlc -vvv "playlist_meta.m3u" --sout '#transcode{vcodec=none,acodec=mp3,ab=128}:standard{access=http,mux=raw,dst=192.168.1.37:8080}' --sout-keep
#cvlc -vvv "01_09_Psalm.mp3" --sout '#transcode{vcodec=none,acodec=mp3,ab=128}:standard{access=http,mux=raw,dst=192.168.1.37:8080}' --sout-keep
