var lines = new Array();
var store_it = new Array();

function handleFiles(files) {
	// Check for the various File API support.
	if (window.FileReader) {
		// FileReader are supported.
		getAsText(files[0]);
	} else {
		alert('FileReader are not supported in this browser.');
	}
}

function getAsText(fileToRead) {
	var reader = new FileReader();
	// Handle errors load
	reader.onload = loadHandler;
	reader.onerror = errorHandler;
	// Read file into memory as UTF-8      
	reader.readAsText(fileToRead);
}

function loadHandler(event) {
	var csv = event.target.result;
	processData(csv);             
}


function processData(csv) {
    var allTextLines = csv.split(/\r\n|\n/); 

    while (allTextLines.length) {
        lines.push(allTextLines.shift().split(','));
        store_it.push(allTextLines.shift().split(','));
    }
	console.log(lines);
	console.log(store_it);
	drawOutput(lines);
}

function errorHandler(evt) {
	if(evt.target.error.name == "NotReadableError") {
		alert("Cannot read file !");
	}
}


function drawOutput(lines){
	//Clear previous data
	document.getElementById("output").innerHTML = "";
	var headers = document.getElementById("headers");

	var table = document.createElement("table");
	var txt = "";
	for (var i = 0; i < 10; i++) {
		var row = table.insertRow(-1);

		if(lines[i].length != 0){
			for (var j = 0; j < lines[i].length; j++) {

				var firstNameCell = row.insertCell(-1);

	
				if(headers.value == 1)
				{
					if(i == 0 && lines[i].length > 1){
						txt += "<label><input type=\"checkbox\" id=\"Column" + j + "\" name=\"Column[" + j + "]\" value=\"0\" onClick=\"columnsToHash();\" ></label>";

						//txt += "<label><input type=\"checkbox\" id=\"Column" + j + "\" name=\"Column[" + j + "]\" value=\"0\" onClick=\"columnsToHash()\" ></label>";

					}
					else if(i == 0)
					{
						txt += "<input type=\"hidden\"  id=\"Column0\" name=\"Column[0]\" value =\"1\"  onClick=\"columnsToHash();\" >";
					}

					if(i == 0 && j == 0)
					{

						for (var k = 0; k < lines[k].length; k++) 
						{
							firstNameCell.appendChild(document.createTextNode("Column " + k));
							firstNameCell = row.insertCell(-1);				
						}
					}
				}

				else
				{

					if(i == 0 && lines[i].length > 1){

						//txt += "<label><input type=\"checkbox\" id=\"Column" + j + "\" name=\"Column[" + j + "]\" value=\"0\" > " + firstNameCell.appendChild(document.createTextNode(lines[0][j])).textContent + "</label>";
					
txt += "<label><input type=\"checkbox\" id=\"Column" + j + "\" name=\"Column[" + j + "]\" value=\"0\" onClick=\"columnsToHash();\" > " + firstNameCell.appendChild(document.createTextNode(lines[0][j])).textContent + "</label>";
					
					}
					else if(i == 0 && lines[i].length <= 1)
					{
						txt += "<input type=\"hidden\" id=\"Column0\" name=\"Column[0]\" value =\"1\" onClick=\"columnsToHash();\" >";
						
					}					
				}

			firstNameCell.appendChild(document.createTextNode(lines[i][j]));
			}

		}
		document.getElementById("output").innerHTML = txt;

		document.getElementById("output").appendChild(table);
	}
}
/*
function checkme(myid) {
    var x = document.getElementById(myid);
    x.checked = true;
}

function uncheckme(myid) {
    var x = document.getElementById(myid);
    x.checked = false;
}
*/



function columnsToHash()
{

    for (var i = 0; i < lines.length; i++) {

        for (var j = 0; j < lines[i].length; j++) {

	var col = document.getElementById("Column" + j );
	


	if(col.checked == true)
		{

		store_it[i][j] = lines[i][j]; 

	} 	
	else
	{
		store_it[i][j] = "@££$$@";

	}	
}
    }

 document.getElementById("selected_col").value = store_it.map(e => e.join(':')).join(';'); // 1:2;3:4
	//console.log(store_it);
}





