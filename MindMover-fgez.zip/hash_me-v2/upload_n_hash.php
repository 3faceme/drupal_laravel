<!DOCTYPE html>
<!--[if IE 9]><html class="lte-ie9"><![endif]-->
<!--[if lte IE 8]><html class="lte-ie9 lte-ie8"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html><!--<![endif]-->
<head>
<meta name="robots" content="noindex, nofollow, noarchive" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- respview.client.meta -->


<title>Email Hashing version 2.0</title>


<!-- respview.css -->
<link rel="stylesheet" href="https://surveys.globaltestmarket.com/s/exp/support/jquery-ui-1.9.2.custom/css/smoothness/jquery-ui-1.9.2.custom.min.css?ad7753b880" />
<link rel="stylesheet" href="https://surveys.globaltestmarket.com/s/exp/support/jquery-ui-1.9.2.custom/css/smoothness/jquery-ui-1.9.2.beacon.css?3e119d5110" />
<link rel="stylesheet" href="https://surveys.globaltestmarket.com/s/fonts/iconFonts.css"/>
<!-- generated from: static/support/font-awesome-4.2.0/less/font-awesome.less, static/survey.respondent-post125.less, static/nthemes/system/themes/contemporary/theme.less and 0 themevars -->
<link rel='stylesheet' href='https://surveys.globaltestmarket.com/survey/emea/v2/Francois/fg_webgl/less-compiled.css?27e106ce6a56848505e34cd33b3d5a77'>



<!-- extra CSS -->



<!-- respview.client.css -->
<link rel="stylesheet" type="text/css" href="https://surveys.globaltestmarket.com/s/local/bor/themev2.css"/>
<link rel="stylesheet" type="text/css" href="https://surveys.globaltestmarket.com/s/local/2013Template/blue.css"/>

<!-- client.css -->
<style media="screen">

</style>

<style>
p.ex1,ul.ex1
{
margin-left: 2cm;

}

ul.menu1 {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
    height: 67px;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #f7941e;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    min-height: 60px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

html, body, div, span, applet, object, iframe, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, font, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset,
 form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td {
    margin: 5px;
    font-size: 101%;

}


h1 {
    margin: 10px;
    font-size: 105%;

}

h2, h3, h4, h5, h6
{
    margin: 10px;
    font-size: 103%;

}


img.image1 {
  /*whatever you want to do here*/
}

img.image2 {
  /*whatever you want to do here*/
    margin: -94px 100px -11px 771px;
}
</style>

<?php

include($_SERVER['DOCUMENT_ROOT']."/hash_me-v2/" . "prepare_file.php;");

define("UPLOAD_DIR", "/var/www/html/hash_me-v2/uploads/");
define("CSV_DIR", "/var/www/html/hash_me-v2/uploads/");

define("TIMESTAMP", date('d-m-Y-H-i-s'));

define("COUNT_IT", 10);

$zip = new ZipArchive();

$file_name = TIMESTAMP . 'data.zip';


$hash_flag = $_REQUEST["chooseone"];
$case_flag = $_REQUEST["choosecase"];
$postcase = $_REQUEST["postcase"];
$trim_or_not = $_REQUEST["trim_or_not"];
$selected_col = $_REQUEST["store_it"];

$selected_lo = strtolower($selected_col);
$selected_up = strtoupper($selected_col);


//Implementing the case and hashing here:

//$file_uploaded = fopen($filepath, "r");
$hash_it = array();
$linescase = array();
$hashcase = array();
$inc = 0;

	if($case_flag == 0)
	{
	$selected_col = $selected_col;
	}
	else if($case_flag == 1)
	{
	$selected_col = $selected_lo;
	}		
	else if($case_flag == 2)
	{
	$selected_col = $selected_up;
	}		


foreach($selected_col = explode(";",$selected_col) as &$tmpvalue) 
{

	$value = explode(':',$tmpvalue);

	$linescase[$inc] = $value;
	


if($trim_or_not == 1)
{
	if ($hash_flag == 0)
	{
	$hash_it[$inc] = hash('sha1', trim($linescase[$inc]), false);
	}

	elseif ($hash_flag == 1)	
	{
	$hash_it[$inc] = hash('sha256', trim($linescase[$inc]), false);
	}

	elseif ($hash_flag == 2)
	{
	$hash_it[$inc] = hash('sha512', trim($linescase[$inc]), false);
	}

	else
	{
	$hash_it[$inc] = hash('md5', trim($linescase[$inc]), false);
	}
}



else if($trim_or_not !== 1)
{

/*

    " " (ASCII 32 (0x20)), an ordinary space.
    "\t" (ASCII 9 (0x09)), a tab.
    "\n" (ASCII 10 (0x0A)), a new line (line feed).
    "\r" (ASCII 13 (0x0D)), a carriage return.
    "\0" (ASCII 0 (0x00)), the NUL-byte.
    "\x0B" (ASCII 11 (0x0B)), a vertical tab.

*/

//$last_char = substr($linescase[$inc], -1); // returns "s"$linescase[$inc] = str_replace("\r", "", $linescase[$inc]);
$linescase[$inc] = str_replace("\0", "", $linescase[$inc]);
$linescase[$inc] = str_replace("\n", "", $linescase[$inc]);
//$linescase[$inc] = str_replace(" ", "", $linescase[$inc]);
$linescase[$inc] = str_replace("\t", "", $linescase[$inc]);
$linescase[$inc] = str_replace("\x0B", "", $linescase[$inc]);
$linescase[$inc] = str_replace("\r", "", $linescase[$inc]);

//$last_char = substr_replace($linescase[$inc], "", -1);

	if ($hash_flag == 0)
	{
	$hash_it[$inc] = hash('sha1', $linescase[$inc], false);
	}

	elseif ($hash_flag == 1)	
	{
	$hash_it[$inc] = hash('sha256', $linescase[$inc], false);
	}

	elseif ($hash_flag == 2)
	{
	$hash_it[$inc] = hash('sha512', $linescase[$inc], false);
	}

	else
	{
	$hash_it[$inc] = hash('md5', $linescase[$inc], false);
	}
}
else
	print_r("You must select an option");





echo "<br/><pre>Displaying hash_it before postcase: " . print_r($hash_it[$inc]);


	if($postcase == 1)
	{	
		$hash_buff = $hash_it[$inc];
		$hash_buff  = strtolower($hash_buff);		
		$hashcase[$inc]	 = $hash_buff;

	}
	else if($postcase == 2)
	{
		$hash_buff = $hash_it[$inc];
		$hash_buff  = strtoupper($hash_buff);		
		$hashcase[$inc]	 = $hash_buff;
	}		
	else
		print_r("You must select an option");


$inc++;
} // End Foreach


/*
$output = print_r($hashcase, true);


$file_csv = UPLOAD_DIR . TIMESTAMP . 'hashed.csv';
 
	$fp1 = fopen( $file_csv, 'a+');


file_put_contents( UPLOAD_DIR . TIMESTAMP . $shortname .  '.csv', implode(PHP_EOL, $hashcase));


fclose($fp1);

if ($zip->open($_SERVER['DOCUMENT_ROOT']."/hash_me/uploads/" . $file_name, ZIPARCHIVE::CREATE) != TRUE) {
        die ("Could not open archive");
}

    $zip->addFile($file_csv, "hashed-" . $shortname );

// close and save archive

$zip->close(); 

*/

?>
<!--
<script type="text/javascript" language="Javascript">
var file_name = "<?php echo $file_name; ?>";
window.open('./uploads/'+ file_name );
</script>
-->

</head>

<body class="survey-page non-touch">

<!--NEW! -->
<ul class="menu1">
  <li class="menu1"><a class="active" href="index.html">Home</a></li>
  <li class="menu1"><a href="contactform.html">Feedback</a></li>
  <li class="menu1"><a href="authenticate.html">Register/Login</a></li>
  <li class="dropdown">
<!--
    <a href="" class="dropbtn">Forum</a>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
-->
  </li>
</ul>

<div id="survey">
<div class="surveySection"><div id="surveyHeader" class="survey-header group">


</div>
<!-- /#surveyHeader --></div>
<div class="surveySection">
<div id="surveyContent" class="survey-page-content group">
<div id="ko-outersurveypage">
<div id="menu-up">
<a href="#inline_content" class="inline">
<div id="menu" style="height:5px;">

<div id="mButton" style="position:relative;float:right;display:none">

</div>
</div>
</a>

<div class="colorpicker" id="colorpicker">
 <img src="lightspeed.png" alt="Lightspeed logo" class="image1"> 
 <img src="hashtool_logo.png" alt="Hashtool logo" class="image2"> <br/>
<div id="developed_by" align="right" style="font-size: 50% !important;margin-right: 71px;margin-top: 19px;">
Developed by Fran&ccedil;ois Gez<br/>Version 2.0 - Led Zeppelin
</div>

<h2 title="question" class="survey-q-question-text"> 
You will now be prompted to download your file(s) in zip format.

  </h2>
</div>
<!--
  <?php 
$subdom=  TIMESTAMP . 'data.zip';
?>


     <a href="http://localhost/hash_me-v2/uploads/<?php echo $subdom;?>">Click here if you are stuck!</a>

</div>
</div>
-->



<div id='wndcover' style='position:absolute;left:0;top:0;width:99%;height:99%;background:#474747;opacity:0.85;filter:alpha(opacity=85);-moz-opacity:0.85;display:none;z-index:1000001;'></div>
<div style='position:absolute;display:none;border:1px solid #AAA;white-space:nowrap;z-index:1000002' id='inline_content1' data-rel="dialog">

<img src="https://surveys.globaltestmarket.com/s/local/2013Template/OM/close.png" style="position:absolute;left:-20px;top:-20px;height:33px;width:33px;">

</div>
<div class="clearfix surveyProgressBar survey-progress survey-progress-align survey-progress-topgroup" title="progress bar - 0% complete">
<div class="survey-progress-box bar survey-progress-bar survey-progress-bar-remaining survey-progress-bar-borders"><span class="survey-progress-fill survey-progress-bar-completed" style="width: 0%;"></span></div>
<div class="survey-progress-text">0%</div>
</div>
<!-- /.surveyProgressBar -->

<!-- @@XYZZY@@ -->
<div id="question_Q1" class="survey-q surveyQuestion radio label_Q1  ">
<div class="question survey-q-question">




<!-- /.question -->

<div class="instructions survey-q-instructions">
<h3 title="instructions" class="survey-q-instructions-text"></h3>
</div>
<!-- /.instructions -->
<div class="answers survey-q-answers survey-q-answers-list">
<div class='fir fir-checkbox' style="display: none;">
<span class="fir-icon">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 22 22" class="rounded">
<pathd="M15.8,0H3.9C1.8,0,0,2,0,4.1V16c0,2.2,1.8,4,3.9,4h11.8c2.2,0,4.2-1.8,4.2-4V4.1C20,2,18,0,15.8,0zM19,16c0,1.6-1.6,3-3.2,3H3.9C2.3,19,1,17.7,1,16V4.1C1,2.5,2.3,1,3.9,1h11.8C17.4,1,19,2.5,19,4.1V16z" class="fir-base"></path>
<pathd="M19,16c0,1.6-1.6,3-3.2,3H3.9C2.3,19,1,17.7,1,16V4.1C1,2.5,2.3,1,3.9,1h11.8C17.4,1,19,2.5,19,4.1V16z" class="fir-bg">
</path>
<polygon points="9.1,16.3 2.5,11 4.1,9 8.7,12.6 15.6,3.7 17.7,5.2 " class="fir-selected"></polygon>
</svg>
</span>
</div>
<div class='fir fir-radio' style="display: none;">
<span class="fir-icon">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 22 22" class="rounded">
<circle cx="10" cy="10" r="10" class="fir-base"></circle>
<circle cx="10" cy="10" r="9"  class="fir-bg"></circle>
<circle cx="10" cy="10" r="7"  class="fir-selected"></circle>
</svg>
</span>
</div>
<div id="surveyButtons" class="styled group survey-buttons">


<!-- /.grid -->
</div>
<!-- /.answers -->
</div>

<!-- #surveyButtons --><INPUT type="hidden" name="state" value="b1f36c263db427b607cef4806f3bc8fc31510c15Q000013P000001db"/>
<INPUT type="hidden" name="start_time" value="1468834388"/>


</div>



</div>
<!-- /#surveyContent -->
</div>
<div class="surveySection"><div id="surveyFooter"><div class="footer"></div></div></div>
</div>
<div id="detectBreakpoint"></div>
<!-- /#survey -->
</body>
</html>

