<?php

namespace LSR\Hash\Helper;



Final Class CaseHandler {


    /**
     *
     * @var type 
     */
    public $content;

    /**
     * 
     * @param type $content
     * @return \LSR\Hash\Helper\CaseHandler
     */
    public function setContent($content) {
        $this->content = $content;
        return $this;
    }

    /**
     * 
     * @param type $name
     * @return \LSR\Hash\Helper\CaseHandler
     */
    public function setMethod($name) {
        $this->method = $name;
        return $this;
    }

    /**
     * 
     * @return type
     */
    public function getMethod() {
        return $this->method;
    }


    /**
     * 
     * @param type $file
     * @return type
     */
    public function lowercase($file = false) {
        if ($file) {
            return strtolower($this->content);
        } else {
		return $this->content;
        }
    }

    /**
     * 
     * @param type $file
     * @return type
     */
    public function uppercase($file = false) {
        if ($file) {
            return strtoupper($this->content);
        } else {
		return $this->content;
        }
    }


}
