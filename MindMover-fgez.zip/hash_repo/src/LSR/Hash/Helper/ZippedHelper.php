<?php

 

namespace LSR\Hash\Helper;

/**
 * Description of ZippedHelper
 *
 * @author ManaraR
 */
class ZippedHelper {
    //put your code here
}
