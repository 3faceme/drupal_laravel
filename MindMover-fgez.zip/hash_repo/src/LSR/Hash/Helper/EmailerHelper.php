<?php

namespace LSR\Hash\Helper;

use PHPMailer;

/**
 * Description of EmailerHelper
 *
 * @author ###
 */
class EmailerHelper {

    //put your code here

    private $mail;

    /**
     * 
     * @param type $from
     * array(
     *          'email' =>''
     *          'name' =>''
     * ) required
     * @param type $to
     * * array(
     *      'email' =>''
     *      'name' =>''
     * ) required
     * @param type $cc
     * * array(
     *      'email' =>''
     *      'name' =>''
     * ) optional 
     */
    public function __construct($from = array(), $to = array(), $cc = array()) {

        if (empty($from) || !isset($from['email']) and !isset($from['name'])) {
            throw new \Exception("from: email or name is not define");
        }


        if (empty($to) || !isset($to['email']) and !isset($to['name'])) {
            throw new \Exception("to: email or name is not define");
        }


        $this->mail = new PHPMailer;
        $this->mail->setFrom($from['email'], $from['name']);
        $this->mail->addAddress($to['email'], $to['name']);
        $this->mail->isHTML(true);
        
        if (!empty($cc)) {

            if (empty($cc) || !isset($cc['email']) and !isset($cc['name'])) {
                throw new \Exception("cc: email or name is not define");
            }

            $this->mail->addAddress($cc['email'], 'John Doe');
        }
    }

    /**
     * 
     * @param type $subject
     * @param type $body
     */
    public function body($subject = null, $body = null) {
        $this->mail->Subject = $subject;
        $this->mail->Body = $body;
    }

    /**
     * 
     * @param type $files
     */
    public function attachement($files = array()) {
         
        foreach ($files as $file) {
            $this->mail->addAttachment($file['path'], $file['name']);
        }
    }

    /**
     * 
     * @return array
     */
    public function send() {
        
        if (!$this->mail->send()) {
            return array('error' => "Mailer Error: " . $this->mail->ErrorInfo);
        } else {
            return array('success' => "Message sent!");
        } 
        
    }

}
