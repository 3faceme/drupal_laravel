<?php

namespace LSR\Hash\Controller;


use Application\App\AbstractController as Controller;
/**
 * Description of FeedBackController
 *
 * @author ###
 */
class FeedBackController extends Controller{

    /**
     * Feed Back Page
     */
    public function FeedBackPage() {

        $model = new \LSR\Hash\Model\FeedBackModel();

        $msn = '';
        if ($this->getRequest()->getMethod() == "POST") {

            $msn = "Thank you for your feedback! Message sent to the team!";

            $array = array(
                'name' => $this->getRequest()->get('name'),
                'comment' => $this->getRequest()->get('comment'),
                'score' => $this->getRequest()->get('score'),
            );

            $to = array('email' => '###', 'name' => 'Automated Hashed Emailer',);
            // check if has a member logged or not

            if ($model->saveData($array)) {
                $email = new \Application\Helper\EmailerHelper($to);
                $email->body('Feedback', $this->getHtml("User/feedback.email.html.twig", array(
                            'name' => empty($array['name']) ? $to['name'] : $array['name'],
                            'content' => $array['comment']
                )));
                $email_msn = $email->send();
                $msn .= "<br/>" . isset($email_msn['success']) ? $email_msn['success'] : $email_msn['error'];
            } else {
                $msn = "feedback wasn't sent, something when wrong!!!";
            }
        }
        $this->view("User/feedback.html.twig", array(
            'form_url' => $this->getRequest()->getRequestUri(),
            'msn' => $msn,
        ));
    }

}
